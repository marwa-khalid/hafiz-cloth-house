const BillingInfoPage = async (request, response, next) => 
{
    response.render("./BillingInfo");
}
module.exports = {
    BillingInfoPage
};