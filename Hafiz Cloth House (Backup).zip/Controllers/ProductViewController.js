const ProductViewPage = async (request, response, next) => 
{
    response.render("./ProductView");
}
module.exports = {
    ProductViewPage
};