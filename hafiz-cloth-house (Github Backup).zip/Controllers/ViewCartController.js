const ViewCartPage = async (request, response, next) => 
{
    response.render("./ViewCart");
}
module.exports = {
    ViewCartPage
};