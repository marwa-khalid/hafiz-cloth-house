const AboutUsPage = async (request, response, next) => 
{
    response.render("./AboutUs");
}
module.exports = {
    AboutUsPage
};